import asyncio
import json
from av import VideoFrame
import logging
import time
import os
from django.http import HttpResponse
from django.shortcuts import render
import json
from webrtc import customVideoTrack
import uuid
from aiortc import (
    MediaStreamTrack,
    RTCPeerConnection,
    RTCSessionDescription,
    RTCConfiguration,
    RTCIceServer,
)
from aiortc.contrib.media import MediaRelay
from webrtc.P2SRTCPeer import P2SRTCPeer
from webrtc.S2SRTCPeer import S2SRTCPeer
from django.views.decorators.csrf import csrf_exempt

ROOT = os.path.dirname(__file__)
logger = logging.getLogger("pc")
pc = RTCPeerConnection()

p2s = set()
s2s = set()


async def p2sHttpIndex(request):
    return render(request, "./p2sHttp.html")


@csrf_exempt
async def p2sOffer(request):
    params = json.loads(request.body)
    con = P2SRTCPeer(fun, video=video)
    p2s.add(con)
    res = await con.handle(params=params, set=p2s)
    print(p2s)
    return HttpResponse(res)


def fun(f):
    p2s.discard(f)
    print(p2s)


@csrf_exempt
async def s2sOffer(request):
    global video
    con = S2SRTCPeer()
    res = await con.handle(request=request)
    video = con.getS()
    return res
    # pc = RTCPeerConnection()
    # obj = object_from_string(request.body)

    # @pc.on("datachannel")
    # def on_datachannel(channel):
    #     print("recieved a channel")

    #     @channel.on("message")
    #     def on_message(message):
    #         print("<", message)

    # if isinstance(obj, RTCSessionDescription):
    #     await pc.setRemoteDescription(obj)
    #     await pc.setLocalDescription(await pc.createAnswer())
    #     print("local:", pc.localDescription, "remote:", pc.remoteDescription)
    #     return HttpResponse(object_to_string(pc.localDescription))
    #     # return web.Response(text=object_to_string(pc.localDescription))

    # else:
    #     print("error")
    # loop = asyncio.get_event_loop()
    # await loop.run_in_executor(None, input)
    # # return web.Response(text="bad req")
    # return HttpResponse(json.loads('{"msg":"helo"}'))
